getwd()
path <- "/home/sas/R smrad/data for 6 lab"
setwd(path)
#filename <- "test_data.txt"
filename2 <- "data2.dat"
#test_data.txt поврежден, поэтому его невозможно использовать
#data <- read.table(filename, header= TRUE)
data2 <- read.table(filename2, header= TRUE)

source("lab4.R")
#анализ сырых данных
main_komponents(path, filename2)

library(cluster)

# задание числа кластеров
k <- 3 

# выполнение кластерного анализа методом k-медоидов
kmed <- pam(data2, k)  

#kmed$clustering` содержит информацию о принадлежности каждого наблюдения к кластеру. 
#Цвет каждой точки на диаграмме рассеяния соответствует принадлежности кластеру.
plot(kmed$data, col=  kmed$clustering)