getwd()
path <- "/home/sas/R smrad/data for 6 lab"
setwd(path)
#filename <- "test_data.txt"
filename2 <- "data3.dat"
#test_data.txt поврежден, поэтому его невозможно использовать
#data <- read.table(filename, header= TRUE)
data <- read.table(filename2, header= TRUE)
data <- data.frame(data)
source("lab4.R")
#анализ сырых данных
main_komponents(path, filename2)

k <- 3 # количество предполагаемых кластеров

# Шаг 1 - инициализация
k <- 3 # количество кластеров
m <- 1 # номер итерации
precision <- 0.001 # точность вычисления

# Случайно выбираем k объектов из данных в качестве начальных медоидов
set.seed(123)
initial_medoids <- sample(1:nrow(data), k)
M <- data[initial_medoids, ]
cluster <- rep(0, nrow(data)) # вектор для хранения номера кластера для каждого объекта

# Функция для вычисления расстояния между объектами
distance <- function(x1, x2) {
  sqrt(sum((x1 - x2)^2))
}

# Функция для вычисления значения функционала качества кластеризации
quality <- function(data, M, cluster) {
  total_distance <- 0
  for (i in 1:nrow(data)) {
    total_distance <- total_distance + distance(data[i, ], M[cluster[i], ])
  }
  total_distance
}

# Шаг 2 - расчет расстояний и заполнение матрицы U(m)
while (TRUE) {
  # Расчет расстояний от объектов до медоидов
  distances <- matrix(0, nrow(data), k)
  for (i in 1:nrow(data)) {
    for (j in 1:k) {
      distances[i, j] <- distance(data[i, ], M[j, ])
    }
  }
  
  # Заполнение матрицы U(m)
  U <- matrix(0, nrow(data), k)
  for (i in 1:nrow(data)) {
    cluster[i] <- which.min(distances[i, ])
    U[i, cluster[i]] <- 1
  }
  
  # Расчет значения функционала качества кластеризации Q(m)
  Q_prev <- if (m == 1) Inf else Q
  
  Q <- quality(data, M, cluster)
  
  # Шаг 3 - условие остановки
  if (Q_prev - Q < precision) {
    break
  }
  
  # Шаг 4 - расчет новых медоидов
  for (j in 1:k) {
    M[j, ] <- colMeans(data[cluster == j, ])
  }
  
  # Шаг 5 - обновление значения Q(m-1) и переход к следующей итерации
  Q_prev <- Q
  m <- m + 1
}

# Вывод результатов
print(cluster) # номера кластеров для каждого объекта
print(M) # координаты медоидов
print(Q) # значение функционала качества кластеризации
plot(data[,1], data[,2], col = cluster)
