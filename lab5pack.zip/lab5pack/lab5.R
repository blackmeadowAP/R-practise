getwd()
path <- "/home/sas/R smrad/data for 5 lab"
setwd(path)
getwd()

#пакет для вычисления стандартного евклидового расстояния
#install.packages("distances")
library(distances)

# Загрузка данных
data <- read.table("data1.dat", header= TRUE)
#data

# Использование функции dist для вычисления расстояний, указывая меру в качестве аргумента
dist_euclidean <- dist(data, method = "euclidean")
#dist_euclidean

dist_manhattan <- dist(data, method = "manhattan")
#dist_manhattan

#создание вектора со списком методов связывания
methods <- c("single", "complete", "average")
#methods[1]

#функция принимает на вход данные для кластеризации
#возвращает кофенетические коэффициенты и дендрограммы
cluster_counter <- function(distance, methods){
#удаление всех NA NAN  из матрицы
distance[is.na(distance)] <- 0
distance[is.nan(distance)] <- 0

# Выполнение иерархической кластеризации с помощью функции hclust,
#указывая метод связывания в качестве аргумента

clusters_single <- hclust(distance, method = methods[1])
#clusters_single

clusters_complete <- hclust(distance, method = methods[2])
#clusters_complete

clusters_average <- hclust(distance, method = methods[3])
#clusters_average

#сохранение вычисленных данных в вектор
hclusters <- c(clusters_single, clusters_complete, clusters_average)

library(stats)
library(cluster)

#Вычисление кофонетического коэфф. для каждого объекта hclust dict euclidian
coef_cophenetic_single_euclid<- cophenetic(clusters_single)
coef_cophenetic_complete_euclid <- cophenetic(clusters_complete)
coef_cophenetic_average_euclid<- cophenetic(clusters_average)

#создание таблицы с вычисленными кофенетическими коэффициентами
cophenetic_df <- data.frame(coef_cophenetic_single_euclid, coef_cophenetic_complete_euclid,
                            coef_cophenetic_average_euclid)

#построение дендрограмм
plot(clusters_single)
plot(clusters_complete)
plot(clusters_average)

#вывод максимальных кофонетических коэффициентов. 
#чем больше коэффициент - тем выше качество анализа
print(paste("Максимальный кофонетический коэффициент по SINGLE методу: ", 
            max(cophenetic_df$coef_cophenetic_single_euclid)))
print(paste("Максимальный кофонетический коэффициент по COMPLETE методу: ", 
            max(cophenetic_df$coef_cophenetic_complete_euclid)))
print(paste("Максимальный кофонетический коэффициент по AVERAGE методу: ", 
            max(cophenetic_df$coef_cophenetic_average_euclid)))

return(cophenetic_df)}

#использование функции вычисления кластеров и дендрограмм
euclid_df <- cluster_counter(dist_euclidean, methods)
manhattan_df <- cluster_counter(dist_manhattan, methods)
#manhattan_df

new_dist <- complete.cases(dist_euclidean)
#man_clean <- complete.cases(manhattan_df[2])


#определение количества достоверных кластеров
# Метод k-средних
#используются сырые данные
cluster_quntity_quality <- function(k, data){
kmeans_result <- kmeans(data, centers = k)

# Количество достоверных кластеров
n_clusters <- length(unique(kmeans_result$cluster))

# Центры кластеров
cluster_centers <- kmeans_result$centers

# Внутрикластерная дисперсия
cluster_within_ss <- kmeans_result$tot.withinss / k

# Вывод результатов
cat("Количество достоверных кластеров:", n_clusters, "\n")
cat("Центры кластеров:\n")
print(cluster_centers)
cat("Внутрикластерная дисперсия:", cluster_within_ss, "\n")
}

# Количество кластеров
k <- 320
#используются сырые данные
cluster_quntity_quality(k, data)
#построение диаграммы на основе метода главных компонент
#Выполнить анализ исходных данных с использованием алгоритма метода главных компонент
source("lab4.R")

path <- "/home/sas/R smrad/data for 5 lab"
filename <- "data1.dat"
main_komponents(path, filename)


